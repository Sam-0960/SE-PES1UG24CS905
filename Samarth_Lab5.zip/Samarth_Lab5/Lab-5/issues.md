# Lab 5 Issues - premium_calculator.py

Before: Pylint 5.73/10, Bandit 10 issues (1 high, 5 medium, 4 low), Flake8 19 issues
After: Pylint 10.00/10, Bandit 0, Flake8 0

| Issue | Type | Line(s) | Description | Fix Approach |
|-------|------|---------|-------------|--------------|
| tarfile extractall (B202) | Security - High | 63-65 | The customer uploads the archive and extractall trusts it, so a file named like ../../something can be written outside claims_docs | Go through each member and only extract normal files/folders that stay inside claims_docs |
| SSL check turned off (B323) | Security - Medium | 58 | ssl._create_unverified_context does not check the certificate, so someone in the middle can send fake rates | Use ssl.create_default_context() |
| urlopen with any scheme (B310) | Security - Medium | 59 | urlopen also opens file:// and other schemes, not only web links | Only allow https and download with http.client.HTTPSConnection |
| XML parsing (B314, B405) | Security - Medium | 7, 48 | xml.etree is unsafe for XML from partners (entity expansion attacks) | Used defusedxml.ElementTree |
| /tmp log file (B108) | Security - Medium | 14 | Fixed path in a shared temp folder | Log file is now in the current folder on every OS |
| Binding to 0.0.0.0 (B104) | Security - Medium | 12 | Would listen on every network interface | Changed to 127.0.0.1 |
| Hardcoded token (B105) | Security - Low | 13, 103 | The underwriter token is written in the code and also passed in main | Read it from the UNDERWRITER_TOKEN environment variable, compare with hmac.compare_digest |
| random for policy number (B311) | Security - Low | 37 | random numbers can be guessed | Used secrets.randbelow |
| Bare except with continue (B112, E722) | Bug | 53-54 | Skips every kind of error without saying what | Catch only TypeError and ValueError |
| Mutable default discounts=[] (W0102) | Bug | 17, 27 | The list is shared and 500 is added to it on every call, so Quote 2 came out 5500 instead of 6000 and later quotes kept getting cheaper | Default is None and the function does not change the list anymore |
| "no" counted as smoker | Bug (found by running) | 92 | smoker="no" is a non-empty string so it is True and the non-smoker got the 1.3 smoker charge | smoker must be True/False, otherwise TypeError. main passes False |
| Negative premium | Bug (found by running) | 25-26, 93 | Three 3000 discounts made the life premium -800 | Discounts can not take the premium below the base rate for that policy |
| Wrong age | Bug (found by running) | 30-34 | Only subtracts years, so 31-12-1990 gave 36 when the person is still 35 | Subtract 1 if the birthday has not come yet this year, error for a future date |
| Instalment rounded down | Bug (found by running) | 67-71 | math.floor drops the paise, and months=0 returned the full premium | round to 2 decimals, error if months is 0 or less |
| Renewal on 29 Feb crashes | Bug | 79-81 | replace(year=...) fails if the next year is not a leap year | Use 28 Feb in that case |
| Too many arguments (R0913, R0917) | Code quality | 17 | calculatePremium took 6 arguments | Put age, sum insured, smoker and claims into an Applicant dataclass |
| Files not closed safely (R1732, W1514) | Code quality | 42, 63 | open and tarfile.open without with, no encoding | Used with and encoding="utf-8" |
| Naming, docstrings, if/else (C0103, C0114, C0116, R1705, R1703, C0200, C0209) | Style | Many | camelCase names, no docstrings, else after return, range(len()), % formatting | snake_case names, docstrings, simpler returns, enumerate, f-strings |
| Blank lines and long lines (E302, E305, E501, C0301) | Style | Many | One blank line between functions and lines over 79 characters | Two blank lines between functions, long lines split |
