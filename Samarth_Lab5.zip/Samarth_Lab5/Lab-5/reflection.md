# Reflection - Lab 5

1. Which issues were the easiest to fix, and which were the hardest? Why?

Easiest were the Flake8 ones. Most of them were just E302 (needs two blank lines between functions) and a few long lines, so it was only formatting. Pylint naming and docstrings were also easy but took time because there were a lot of functions.

The hardest was the tarfile one. My Python version does not have the filter option for extractall, so I had to check each file in the archive myself and skip anything that goes outside the folder or is a link. The URL one was also annoying because Bandit still showed B310 even after I checked for https, so I changed it to use HTTPSConnection.

2. Did the static analysis tools report any false positives? If so, describe one example.

B310 felt like a false positive after my first fix. I had already checked that the URL starts with https but Bandit still reported it, because it flags every urlopen call no matter what. The bigger problem was the other way around: the tools missed real bugs. The shared discounts list, "no" being treated as a smoker, the negative premium and the wrong age were only visible when I ran the program and looked at the numbers. Pylint only warned about the default [] argument, it could not tell me it was actually changing the quotes.

3. How would you integrate static analysis tools into your actual software development workflow?

I would run Flake8 and Pylint in the editor so I see problems while typing, and run Bandit before every commit with a pre-commit hook. For a group project I would add a GitHub Actions check so a pull request can not be merged if Bandit finds something high or medium. But I would still write tests, because this lab showed the tools do not check if the output is correct.

4. What tangible improvements did you observe in the code quality, readability, or potential robustness after applying the fixes?

Pylint went from 5.73 to 10, Bandit from 10 issues to 0 and Flake8 from 19 to 0. The quotes are correct now: the same customer gets the same price, a non-smoker is not charged extra, discounts can not make the premium negative and the age is right. It is also safer, because uploaded archives and partner XML can not be used to attack the system and the token is not in the code. The Applicant dataclass made calculate_premium easier to read than six separate arguments.
