"""Insurance premium calculator for health, motor and life policies."""

import os
import ssl
import hmac
import secrets
import tarfile
import http.client
import urllib.parse
from dataclasses import dataclass
from datetime import date, datetime

import defusedxml.ElementTree as ET

# Global quote book
quotes = {}
HOST = "127.0.0.1"
UNDERWRITER_TOKEN = os.environ.get("UNDERWRITER_TOKEN", "")
LOG_FILE = "premium_quotes.log"
BASE_RATES = {"health": 5000, "motor": 3000, "life": 8000}


@dataclass
class Applicant:
    """Details of the person asking for a quote."""
    age: int
    sum_insured: int
    smoker: bool = False
    claims: int = 0


def calculate_premium(policy_type, applicant, discounts=None):
    """Return the yearly premium for a policy type and applicant."""
    if discounts is None:
        discounts = []
    if not isinstance(applicant.smoker, bool):
        raise TypeError("smoker must be True or False")
    base = BASE_RATES[policy_type]
    premium = base + applicant.sum_insured * 0.002
    if applicant.age > 45:
        premium = premium * 1.5
    if applicant.smoker:
        premium = premium * 1.3
    premium = premium + applicant.claims * 1000
    # discounts can not take the premium below the base rate
    premium = max(premium - sum(discounts), float(base))
    return round(premium, 2)


def age_from_dob(dob):
    """Return the age in years for a date of birth in DD-MM-YYYY format."""
    born = datetime.strptime(dob, "%d-%m-%Y").date()
    today = date.today()
    if born > today:
        raise ValueError("date of birth is in the future")
    age = today.year - born.year
    if (today.month, today.day) < (born.month, born.day):
        age = age - 1  # birthday has not come yet this year
    return age


def policy_number():
    """Return a new random policy number."""
    return "POL-" + str(secrets.randbelow(900000) + 100000)


def save_quote(name, premium):
    """Save a quote in the quote book and the log file, return its number."""
    number = policy_number()
    quotes[number] = {"name": name, "premium": premium}
    with open(LOG_FILE, "a", encoding="utf-8") as log:
        log.write(f"{number},{name},{premium:.2f}\n")
    return number


def import_policies(xml_text):
    """Read policies from partner XML and skip the ones with bad values."""
    root = ET.fromstring(xml_text)
    result = []
    for policy in root.findall("policy"):
        try:
            result.append((policy.get("type"),
                           int(policy.get("age")),
                           int(policy.get("sum"))))
        except (TypeError, ValueError):
            continue
    return result


def fetch_rates(url):
    """Download a rate table over https with certificate checks."""
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https" or not parts.hostname:
        raise ValueError("rate tables can only be downloaded over https")
    ctx = ssl.create_default_context()
    conn = http.client.HTTPSConnection(parts.hostname, parts.port,
                                       context=ctx, timeout=10)
    path = parts.path or "/"
    if parts.query:
        path = path + "?" + parts.query
    try:
        conn.request("GET", path)
        return conn.getresponse().read()
    finally:
        conn.close()


def import_claim_documents(archive_path):
    """Extract a customer's claim archive, skipping unsafe entries."""
    target = os.path.realpath("claims_docs")
    with tarfile.open(archive_path) as tar:
        for member in tar.getmembers():
            dest = os.path.realpath(os.path.join(target, member.name))
            if not (member.isfile() or member.isdir()):
                continue
            if os.path.commonpath([target, dest]) != target:
                continue
            tar.extract(member, target)


def monthly_instalment(premium, months=12):
    """Split a premium into monthly instalments."""
    if months <= 0:
        raise ValueError("months must be more than 0")
    return round(premium / months, 2)


def is_authorised(token):
    """Check an underwriter token against the one set in the environment."""
    if not UNDERWRITER_TOKEN:
        return False
    return hmac.compare_digest(token, UNDERWRITER_TOKEN)


def renewal_due(start, years=1):
    """Return the renewal date for a policy start date in YYYY-MM-DD format."""
    start_date = datetime.strptime(start, "%Y-%m-%d")
    try:
        renewal = start_date.replace(year=start_date.year + years)
    except ValueError:
        # 29 Feb start and the renewal year is not a leap year
        renewal = start_date.replace(year=start_date.year + years, day=28)
    return renewal.strftime("%Y-%m-%d")


def print_quotes():
    """Print every saved quote."""
    print("===== Quote Book =====")
    for i, (number, quote) in enumerate(quotes.items(), start=1):
        print(i, number, quote["name"], "Rs.", quote["premium"])


def main():
    """Run sample quotes and print the results."""
    p1 = calculate_premium("health", Applicant(30, 500000))
    p2 = calculate_premium("health", Applicant(30, 500000))
    p3 = calculate_premium("motor", Applicant(50, 800000, False))
    p4 = calculate_premium("life", Applicant(25, 100000), [3000, 3000, 3000])
    print("Quote 1:", p1)
    print("Quote 2 (same customer details):", p2)
    print("Non-smoker aged 50:", p3)
    print("Life with stacked discounts:", p4)
    print("Age from DOB 31-12-1990:", age_from_dob("31-12-1990"))
    print("Monthly instalment:", monthly_instalment(p3))
    print("Renewal due:", renewal_due("2025-03-15"))
    sample_xml = ("<policies><policy type='health' age='40' sum='300000'/>"
                  "<policy type='motor' age='abc' sum='1'/></policies>")
    print("Imported:", import_policies(sample_xml))
    print("Saved as:", save_quote("Kiran", p1))
    print("Authorised (wrong token):", is_authorised("guess-123"))
    print("Server would listen on", HOST)
    print_quotes()


if __name__ == "__main__":
    main()
