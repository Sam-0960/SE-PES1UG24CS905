# Lab 5 - Static Code Analysis

Samarth Prabhu K - PES1UG24CS905
Assigned repo: L5_59-insurance-premium-calculator

Files:
- premium_calculator.py - fixed code
- issues.md - table of issues found and fixed
- reflection.md - answers to the reflection questions
- reports/before, reports/after - pylint, bandit and flake8 reports

| Tool | Before | After |
|------|--------|-------|
| Pylint | 5.73/10 | 10.00/10 |
| Bandit | 10 issues | 0 |
| Flake8 | 19 issues | 0 |

To run it you need defusedxml: `pip install defusedxml`
